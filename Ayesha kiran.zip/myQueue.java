class Node {
    int data;
    Node next;

    Node(int val) {
        data = val;
        next = null;
    }
}

public class myQueue {

    private Node Front;
    private Node rear;

    public myQueue() {
        Front = rear = null;
    }

    // Insert element into queue
    public void enqueue(int val) {
        Node node = new Node(val);

        if (isEmpty()) {
            Front = rear = node;
        } else {
            rear.next = node;
            rear = node;
        }
    }

    // Remove element from queue
    public void dequeue() {
        if (isEmpty()) {
            System.out.println("Queue Underflow");
            return;
        }

        Front = Front.next;

        if (Front == null) {
            rear = null;
        }
    }

    // Show front element
    public int peek() {
        if (isEmpty()) {
            System.out.println("Queue is Empty");
            return -1;
        }

        return Front.data;
    }

    // Check whether queue is empty
    public boolean isEmpty() {
        return Front == null;
    }

    // Display all elements
    public void display() {
        if (isEmpty()) {
            System.out.println("Queue is Empty");
            return;
        }

        Node temp = Front;

        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }

        System.out.println();
    }

    public static void main(String[] args) {

        myQueue q = new myQueue();

        q.enqueue(10);
        q.enqueue(20);
        q.enqueue(30);

        System.out.print("Queue: ");
        q.display();

        System.out.println("Front element: " + q.peek());

        q.dequeue();

        System.out.print("After dequeue: ");
        q.display();

        System.out.println("Front element after dequeue: " + q.peek());

        q.dequeue();
        q.dequeue();

        q.display();

        System.out.println("Queue empty: " + q.isEmpty());

        q.dequeue();
    }
}

